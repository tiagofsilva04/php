<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Portal PMS</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="main.css"><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;800&display=swap" rel="stylesheet">
  </head>
  <body>
  <?php
if (isset($_POST["btn_login"])) {
    $sesslogin = $_POST["login"];
    $sesspassword = $_POST["password"];
    include "ligacao.php";

    $query = "SELECT t.*, c.cargo FROM trabalhadores AS t
              INNER JOIN cargos AS c ON t.id_cargo = c.id_cargo
              WHERE t.login='$sesslogin' AND t.password='$sesspassword'";

    $resultado = mysqli_query($con, $query) or die("Erro na seleção!");
    $num_rows = mysqli_num_rows($resultado);

    if ($num_rows == 1) {
        $linha = mysqli_fetch_array($resultado);
        $cargo = $linha["cargo"];

        if (($cargo == "enfermeiro" || $cargo == "médico" || $cargo == "administrador") ) {
            session_start();
            $_SESSION["id_trabalhador"] = $linha["id_trabalhador"];
            $_SESSION["foto"] = $linha["foto"];
            $_SESSION["nome"] = $linha["nome"];
            $_SESSION["cargo"] = $linha["cargo"];
            $_SESSION["login"] = $linha["login"];
            $_SESSION["contacto"] = $linha["contacto"];
            $_SESSION["id_horario"] = $linha["id_horario"];
            header("Location: AP_inicial.php");
            exit;
        } elseif ($cargo == "secretário") {
            session_start();
            $_SESSION["id_trabalhador"] = $linha["id_trabalhador"];
            $_SESSION["foto"] = $linha["foto"];
            $_SESSION["nome"] = $linha["nome"];
            $_SESSION["cargo"] = $linha["cargo"];
            $_SESSION["login"] = $linha["login"];
            $_SESSION["contacto"] = $linha["contacto"];
            header("Location: AP_secretario.php");
            exit;
        } else {
            echo "Cargo inválido.";
            header("refresh:3; url=index.php");
            exit;
        }
    } else {
        echo "Os dados inseridos não existem.";
        header("refresh:3; url=index.php");
        exit;
    }

    mysqli_close($con);
} else {
    // Restante do seu código aqui, se houver
?>
                <div class="main">
      <div class="container a-container" id="a-container">
        <form class="form" id="a-form" method="POST" action="index.php">
          <h2 class="form_title title">Iniciar Sessão
          </h2>
          
          <input class="form__input" type="text" placeholder="ID" name="login" requery>
          <input class="form__input" type="password" placeholder="Password" name="password" requery>
          <button class="form__button button submit" name="btn_login">Iniciar sessão</button>
        </form>
      </div>
      <div class="container b-container" id="b-container">
     
      </div>
      <div class="switch" id="switch-cnt">
        <div class="switch__circle"></div>
        <div class="switch__circle switch__circle--t"></div>
        <div class="switch__container" id="switch-c1">
  <h2 class="switch__title title">
    <br>
    <span style="font-size: 30px;">Sem credenciais?</span>
  </h2>
  <p class="switch__description description">Fale com o seu administrador de rede para que ele lhe forneça as suas credenciais.</p>
</div>
      </div>
    </div>
    <script src="main.js"></script>
            <?php
        }
        ?>
  </body>
</html>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
